# Disable all notifications
$regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\PushNotifications"
Set-ItemProperty -Path $regPath -Name "ToastEnabled" -Value 0

# Disable notifications in Windows Action Center
$regPath2 = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings"
Set-ItemProperty -Path $regPath2 -Name "NOC_GLOBAL_SETTING_ALLOW_TOASTS_ABOVE_LOCK" -Value 0

# Disable Windows Defender notifications (Security Center)
$regPath3 = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings"
Set-ItemProperty -Path $regPath3 -Name "NOC_GLOBAL_SETTING_ALLOW_TOASTS_ABOVE_LOCK" -Value 0

# Disable all Windows Defender alerts
Set-MpPreference -DisableRealtimeMonitoring $true
Set-MpPreference -DisableBehaviorMonitoring $true

# Disable Taskbar notification area icons
$regPath4 = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
Set-ItemProperty -Path $regPath4 -Name "EnableBalloonTips" -Value 0

Write-Host "All notifications have been turned off."
